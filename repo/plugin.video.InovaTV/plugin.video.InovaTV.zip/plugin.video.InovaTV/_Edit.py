import xbmcaddon
MainBase = 'http://inovatv.tk/INOVATV/base64.php'
addon = xbmcaddon.Addon('plugin.video.InovaTV')