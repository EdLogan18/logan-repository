import xbmcaddon

MainBase = 'https://goo.gl/vddr8u'
addon = xbmcaddon.Addon('plugin.video.superlistamilton')