import xbmcaddon

FavIco = 'https://goo.gl/fFpecF'
MainBase = 'maKknqloY12goJ1elaJdfXR-nGCU'
addon = xbmcaddon.Addon('plugin.video.WatchTVBrasil')